from django.shortcuts import render,redirect
from APP_1.models import *

# Create your views here.

def main(request):
    item = PRODUCT.objects.all()
    context = {
        'item':item,
    }
    return render(request,'display.html',context)

def single(request,id):
    
    single_item = PRODUCT.objects.filter(id=id).first()

    context = {
        'single_item':single_item,
    }

    return render(request,'single.html',context)



def add_to_cart(request,ashii):
    user = request.user
    scn_cart = PRODUCT.objects.get(id=ashii)
    Cart(user=user,product=scn_cart).save()
    return redirect("display_page")



def show_cart(request):
    user = request.user
    cart = Cart.objects.filter(user=user)
    amount = 0
    for p in cart:
        value = p.quantity*p.product.price
        amount = amount + value
    totalamount = amount

    return render(request,'addtocart.html',locals())

def item_remove(request,remove_id):
    item_on_cart = Cart.objects.get(id=remove_id)
    item_on_cart.delete()
    return redirect("Showcart")