from django.urls import path
from . import views

urlpatterns = [
    path('',views.main,name='display_page'),
    path('<str:id>',views.single,name='single_page'),

    path('add-to-cart/<int:ashii>',views.add_to_cart,name='Add_to_cart'),
    path('cart/',views.show_cart,name='Showcart'),
    path('remove_cart_item/<int:remove_id>/',views.item_remove,name='remove-item'),
]